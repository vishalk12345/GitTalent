export const environment = {
  production: true,
  gittalentBackendURL:"http://gittalentBackendURL"
};
