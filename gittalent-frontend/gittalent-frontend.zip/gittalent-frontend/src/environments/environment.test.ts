export const environment = {
production: false,
  gittalentBackendURL:"http://gittalentbackend:8080"
};
